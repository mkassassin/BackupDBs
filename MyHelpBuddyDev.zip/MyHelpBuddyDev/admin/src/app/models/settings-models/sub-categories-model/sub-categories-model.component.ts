import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-categories-model',
  templateUrl: './sub-categories-model.component.html',
  styleUrls: ['./sub-categories-model.component.css']
})
export class SubCategoriesModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
