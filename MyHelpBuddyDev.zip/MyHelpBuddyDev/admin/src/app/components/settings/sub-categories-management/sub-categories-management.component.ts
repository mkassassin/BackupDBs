import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-categories-management',
  templateUrl: './sub-categories-management.component.html',
  styleUrls: ['./sub-categories-management.component.css']
})
export class SubCategoriesManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
