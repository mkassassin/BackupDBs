var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PatientBasicDetailsSchema = mongoose.Schema({
   Patient_Name: { type: String },
   Patient_Age: { type: String },
   Patient_Gender: { type: String },
   Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
   User: { type: Schema.Types.ObjectId, ref: 'User' },
   Confirmed_UserType: { type: String }, // PeripheralUser, Doctor, ClusterDoctor
   Confirmed_By: { type: Schema.Types.ObjectId, ref: 'User' },
   Admission_Type: {
      type: String,
      enum: ['Non_Cluster', 'EMS', 'Direct']
   },
   Stemi_Status: {
      type: String,
      enum: ['Stemi_Confirmed', 'Stemi_Not_Confirmed', 'Stemi_Ask_Cardiologist', 'Retake_ECG']
   },
   Risk_Factors: [{
      Diabetes: { type: String },
      Hypertension: { type: String },
      Smoker: { type: String },
      High_Cholesterol: { type: String },
      Previous_History_of_IHD: { type: String },
      Family_History_of_IHD: { type: String }
   }],
   Symptoms: {
      Chest_Discomfort: { type: String },
      Duration_of_Pain: { type: Date },
      Location_of_Pain: { type: String }
   },
   ECG_Taken_date_time: { type: Date },
   Confirmed_ECG: { type: String },
   ECGFile_Array: [{
      Name: {type: String},
      ECG_File: { type: String },
      DateTime: { type: Date }
   }],
   QR_image: { type : String },
   Current_ECG_File: { type: String },
   ST_Elevation: {
      avL: { type: String },
      L1: { type: String },
      avR: { type: String },
      L2: { type: String },
      avF: { type: String },
      L3: { type: String },
      V1: { type: String },
      V2: { type: String },
      V3: { type: String },
      V4: { type: String },
      V5: { type: String },
      V6: { type: String },
      V3R: { type: String },
      V4R: { type: String },
   },
   ST_Depression: {
      L1: {type:String},
      avL: {type:String},
      L2: {type:String},
      avF: {type:String},
      L3: {type:String},
      V1: {type:String},
      V2: {type:String},
      V3: {type:String}
   },
   LBBB: {type: String},
   Doctor_Notes: {type: String},
   EntryFrom:{type: String},
   BPL_Height:{type: String},
   BPL_Weight:{type: String},
   BPL_BP:{type: String},

   FirstAskTime: { type: Date },
   FirstRepailedTime: { type: Date },

   Active_Status: { type: Boolean, required: true },
   If_Deleted: { type: Boolean, required: true },
   },
  { timestamps: true }
);
var VarPatientBasicDetails = mongoose.model('PatientBasic_Mob_Details', PatientBasicDetailsSchema, 'Patient_Basic_Mob_Details');


var TeleECGPatientDetailsSchema = mongoose.Schema({
   Request_Id: { type: String },
   Device_Id: { type: String},
   Device_Management: { type: Schema.Types.ObjectId, ref: 'Device_Management' },
   Patient_Id: { type: String },
   Patient_FName: { type: String },
   Patient_LName: { type: String },
   Patient_Name: { type: String },
   Patient_Age: { type: Number },
   Patient_Gender: { type: String },
   Mobile: { type: String },
   Email: { type: String },
   Height: { type: String },
   Weight: { type: String },
   DateOfBirth: { type: Date },
   ECG_Taken_date_time: { type: Date },
   Confirmed_ECG: { type: String },
   Report_Status: { type: String },
   Report_Description: { type: String },
   ReportPDF: { type: String },
   ReportPDF_File: { type: String },
   ReportDateTime: { type: Date },
   Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
   User: { type: Schema.Types.ObjectId, ref: 'User' },
   Confirmed_UserType: { type: String }, // PeripheralUser, Doctor, ClusterDoctor
   Confirmed_By: { type: Schema.Types.ObjectId, ref: 'User' },
   Admission_Type: {
      type: String,
      enum: ['Non_Cluster', 'EMS', 'Direct']
   },
   Stemi_Status: { type: String }, // Confirmed, Not-Confirmed
   Findings: {
      Severity: { type: String },
      Heart_Rate: {
         HR: {
            AVG: { type: String },
            MIN: { type: String },
            MAX: { type: String },
         }
      },
      Strip_Duration: { type: String },
      Hr_Variability: { type: String },
      ClassificationData: [{ type: String }]
   },
   Risk_Factors: [{
      Diabetes: { type: String },
      Hypertension: { type: String },
      Smoker: { type: String },
      High_Cholesterol: { type: String },
      Previous_History_of_IHD: { type: String },
      Family_History_of_IHD: { type: String }
   }],
   Symptoms: {
      Chest_Discomfort: { type: String },
      Duration_of_Pain: { type: Date },
      Location_of_Pain: { type: String }
   },
   ST_Elevation: {
      avL: { type: String },
      L1: { type: String },
      avR: { type: String },
      L2: { type: String },
      avF: { type: String },
      L3: { type: String },
      V1: { type: String },
      V2: { type: String },
      V3: { type: String },
      V4: { type: String },
      V5: { type: String },
      V6: { type: String },
      V3R: { type: String },
      V4R: { type: String },
   },
   ST_Depression: {
      L1: {type:String},
      avL: {type:String},
      L2: {type:String},
      avF: {type:String},
      L3: {type:String},
      V1: {type:String},
      V2: {type:String},
      V3: {type:String}
   },
   LBBB: {type: String},
   Doctor_Notes: {type: String},
   Was_Thrombolysed: {type: String},
   Lytic_Agent: {type: String},
   Thrombolysed_At: {type: Date},
   Other_Treatments: {type: String},
   ReasonOfDismissal: {type: String},
   EntryFrom:{type: String}, // Device, Manual
   Invited_To: { type: Schema.Types.ObjectId, ref: 'User' },
   Case_Invite_Status: { type: String }, // '', Pending, Accepted, Rejected,
   Case_Status: { type: String }, // Active, Dismissed
   Report_Added: { type: Boolean, required: true },
   Active_Status: { type: Boolean, required: true },
   If_Deleted: { type: Boolean, required: true },
   },
  { timestamps: true }
);
var VarTeleECGPatientDetails = mongoose.model('TeleECG_Patient_Details', TeleECGPatientDetailsSchema, 'TeleECG_Patient_Details');


var TeleECGInviteHistorySchema = mongoose.Schema({
   Patient_Id: { type: Schema.Types.ObjectId, ref: 'TeleECG_Patient_Details' },
   InviteFrom: { type: Schema.Types.ObjectId, ref: 'User' },
   InviteTo: { type: Schema.Types.ObjectId, ref: 'User' },
   InviteStatus: {type: String}, // Pending, Accepted, Rejected, Not-Invited
   InvitedDateTime: {type: Date},
   InviteResponseDateTime: {type: Date},
   InviteType: {type: String}, // Auto, Manual
   Active_Status: { type: Boolean, required: true },
   If_Deleted: { type: Boolean, required: true },
   }, { timestamps: true }
);
var VarTeleECGInviteHistory = mongoose.model('TeleECG_Invite_History', TeleECGInviteHistorySchema, 'TeleECG_Invite_History');


// Offline Patient Details
var OffLinePatientBasicDetailsSchema = mongoose.Schema({
  Patient_Local:{type: String},
  Patient_Name: { type: String },
  Patient_Age: { type: String },
  Patient_Gender: { type: String },
  Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
  User: { type: Schema.Types.ObjectId, ref: 'User' },
  Confirmed_UserType: { type: String }, // PeripheralUser, Doctor, ClusterDoctor
  Confirmed_By: { type: Schema.Types.ObjectId, ref: 'User' },
  Admission_Type: {
     type: String,
     enum: ['Non_Cluster', 'EMS', 'Direct']
  },
  Stemi_Status: {
     type: String,        
  },
  Risk_Factors: [{
     Diabetes: { type: String },
     Hypertension: { type: String },
     Smoker: { type: String },
     High_Cholesterol: { type: String },
     Previous_History_of_IHD: { type: String },
     Family_History_of_IHD: { type: String }
  }],
  Symptoms: {
     Chest_Discomfort: { type: String },
     Duration_of_Pain: { type: Date },
     Location_of_Pain: { type: String }
  },
  ECG_Taken_date_time: { type: Date },
  Confirmed_ECG: { type: String },
  ECGFile_Array: [{
     Name: {type: String},
     ECG_File: { type: String },
     DateTime: { type: Date }
  }],
  QR_image: { type : String },
  Current_ECG_File: { type: String },
  ST_Elevation: {
     avL: { type: String },
     L1: { type: String },
     avR: { type: String },
     L2: { type: String },
     avF: { type: String },
     L3: { type: String },
     V1: { type: String },
     V2: { type: String },
     V3: { type: String },
     V4: { type: String },
     V5: { type: String },
     V6: { type: String },
     V3R: { type: String },
     V4R: { type: String },
  },
  ST_Depression: {
     L1: {type:String},
     avL: {type:String},
     L2: {type:String},
     avF: {type:String},
     L3: {type:String},
     V1: {type:String},
     V2: {type:String},
     V3: {type:String}
  },
  LBBB: {type: String},
  Active_Status: { type: Boolean, required: true },
  If_Deleted: { type: Boolean, required: true },
  },
 { timestamps: true }
);

var VarOfflinePatientBasicDetails = mongoose.model('PatientBasic_Mob_Offline_Details', OffLinePatientBasicDetailsSchema, 'Patient_Basic_Mob_Offline_Details');

module.exports = {
  PatientBasicDetailsSchema: VarPatientBasicDetails,
  TeleECGPatientDetailsSchema: VarTeleECGPatientDetails,
  TeleECGInviteHistorySchema: VarTeleECGInviteHistory,
  OffLinePatientBasicDetailsSchema: VarOfflinePatientBasicDetails
};