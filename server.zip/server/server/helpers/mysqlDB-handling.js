var mysql = require('mysql');
var moment = require('moment');
var TableInfo = require('./MySQLFields_List');
var DataCollect = require('../api/controllers/reports.controller');
var HeaderFields = require('./Report-Fiels');
var Schedule = require('node-schedule');
var CronJob = require('cron').CronJob;

// MySQL Connection Local
var connection = mysql.createConnection({
   host: '10.10.30.156',
   user: 'root',
   password: 'dicn#c7g%vdt',
   database: 'STEMI_Data_Dump',
   multipleStatements: true

});
// // MySQL Connection Stage
// var connection = mysql.createConnection({
//    host: '127.0.0.1',
//    user: 'root',
//    password: 'fhjdcbkjbwicbwd',
//    database: 'STEMI_Data_Dump'
// });
// // MySQL Connection Live
// var connection = mysql.createConnection({
//    host: '127.0.0.1',
//    user: 'dbuser3',
//    password: 'saxsafvtrhyng#$4',
//    database: 'STEMI_Data_Dump'
// });
connection.connect(function(err) {
   if (err) {
      console.error('MySQL Connection Error ');
      console.log(err.stack);
   }
   console.log('MySQL Connectivity, Success!');
});


exports.MySQL_Manage = function () {
   var job = new CronJob('0 0 * * * *', function() {
      async function DataCollectInsert() {
         let result = await DataCollect.AllPatientDetails_List(null, null);
         // MySQL Fields
         let HeadersArr = [];
         var valueArr = [];
         TableInfo.MySQLFields.map(Obj => { if (Obj.Key !== 'id') { HeadersArr.push(Obj.Key);  }});
         HeadersArr = HeadersArr.toString();
         result.MySQLDataArr.map(record => {
            var arrObj = Object.keys(record).map(function (key) { 
               var value = record[key];
               if (TableInfo.DateFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY").toDate() : null;
               }
               if (TableInfo.DateTimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY HH:mm").toDate() : null;
               }
               if (TableInfo.TimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "HH:mm").format("HH:mm:ss") : null;
               }
               if (TableInfo.IntFields.includes(key)) {
                  value = (value !== '' && value !== null) ? parseInt(value, "10") : null;
               }
               return value; 
            });
            valueArr.push(arrObj);
         });

         // MySQL Medication Header
         let HeadersMedArr = [];
         let ValueMedArr = [];
         TableInfo.MySQLMedicationFields.map(Obj => { if (Obj.Key !== 'id') { HeadersMedArr.push(Obj.Key);  }});
         HeadersMedArr = HeadersMedArr.toString();
         result.MedicationArr.map(record => {
            var arrObj = Object.keys(record).map(function (key) { 
               var value = record[key];
               if (TableInfo.DateTimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY HH:mm").toDate() : null;
               }
               return value; 
            });
            ValueMedArr.push(arrObj);
         });

         // MySQL Treatment Modalities
         let HeadersTreatmentArr = [];
         let ValueTreatmentArr = [];
         TableInfo.MySQLTreatmentModalitiesFields.map(Obj => { if (Obj.Key !== 'id') { HeadersTreatmentArr.push(Obj.Key);  }});
         HeadersTreatmentArr = HeadersTreatmentArr.toString();
         result.TreatmentModalitiesArr.map(record => {
            var arrObj = Object.keys(record).map(function (key) { 
               var value = record[key];
               if (TableInfo.DateTimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY HH:mm").toDate() : null;
               }
               return value; 
            });
            ValueTreatmentArr.push(arrObj);
         });

         // MySQL Vessel Stent 
         let HeadersVesselArr = [];
         let ValueVesselArr = [];
         TableInfo.MySQLVesselStentFields.map(Obj => { if (Obj.Key !== 'id') { HeadersVesselArr.push(Obj.Key);  }});
         HeadersVesselArr = HeadersVesselArr.toString();
         result.VesselStentArr.map(record => {
            var arrObj = Object.keys(record).map(function (key) { 
               var value = record[key];
               if (TableInfo.DateTimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY HH:mm").toDate() : null;
               }
               return value; 
            });
            ValueVesselArr.push(arrObj);
         });

         // MySQL Stents
         let HeadersStentArr = [];
         let ValueStentsArr = [];
         TableInfo.MySQLStentsFields.map(Obj => { if (Obj.Key !== 'id') { HeadersStentArr.push(Obj.Key);  }});
         HeadersStentArr = HeadersStentArr.toString();
         result.StentsArr.map(record => {
            var arrObj = Object.keys(record).map(function (key) {
               var value = record[key];
               if (TableInfo.DateTimeFields.includes(key)) {
                  value = (value !== '' && value !== null) ? moment(value, "DD-MMM-YYYY HH:mm").toDate() : null;
               }
               return value; 
            });
            ValueStentsArr.push(arrObj);
         });

         const InsetQueryOne = 'INSERT INTO temp_patient_records(' + HeadersArr + ') VALUES ? ';
         const InsetQueryOneValue = valueArr;
         const InsetQueryTwo = 'INSERT INTO temp_patient_medication(' + HeadersMedArr + ') VALUES ? ';
         const InsetQueryTwoValue = ValueMedArr;
         const InsetQueryThree = 'INSERT INTO temp_patient_treatment(' + HeadersTreatmentArr + ') VALUES ? ';
         const InsetQueryThreeValue = ValueTreatmentArr;
         const InsetQueryFour = 'INSERT INTO temp_patient_vessel(' + HeadersVesselArr + ') VALUES ? ';
         const InsetQueryFourValue = ValueVesselArr;
         const InsetQueryFive = 'INSERT INTO temp_patient_stent(' + HeadersStentArr + ') VALUES ? ';
         const InsetQueryFiveValue = ValueStentsArr;

         Promise.all([
            connection.query(InsetQueryOne, [InsetQueryOneValue]),
            connection.query(InsetQueryTwo, [InsetQueryTwoValue]),
            connection.query(InsetQueryThree, [InsetQueryThreeValue]),
            connection.query(InsetQueryFour, [InsetQueryFourValue]),
            connection.query(InsetQueryFive, [InsetQueryFiveValue]),
         ]).then(response => {
            var DropQuery = "DROP TABLE IF EXISTS patient_records";
            var DropQuery_1 = "DROP TABLE IF EXISTS patient_medication";
            var DropQuery_2 = "DROP TABLE IF EXISTS patient_treatment";
            var DropQuery_3 = "DROP TABLE IF EXISTS patient_vessel";
            var DropQuery_4 = "DROP TABLE IF EXISTS patient_stent";
            Promise.all([
               connection.query(DropQuery),
               connection.query(DropQuery_1),
               connection.query(DropQuery_2),
               connection.query(DropQuery_3),
               connection.query(DropQuery_4)
            ]).then( response_1 => {
               var RenameQuery = "RENAME TABLE temp_patient_records TO patient_records";
               var RenameQuery_1 = "RENAME TABLE temp_patient_medication TO patient_medication";
               var RenameQuery_2 = "RENAME TABLE temp_patient_treatment TO patient_treatment";
               var RenameQuery_3 = "RENAME TABLE temp_patient_vessel TO patient_vessel";
               var RenameQuery_4 = "RENAME TABLE temp_patient_stent TO patient_stent";

               connection.query(RenameQuery, (err, result) => {
                  if (err) {
                     console.log('Error Rename Query');
                  }
               });
               connection.query(RenameQuery_1, (err, result) => {
                  if (err) {
                     console.log('Error Rename Query One');
                  }
               });
               connection.query(RenameQuery_2, (err, result) => {
                  if (err) {
                     console.log('Error Rename Query Two');
                  }
               });
               connection.query(RenameQuery_3, (err, result) => {
                  if (err) {
                     console.log('Error Rename Query Three');
                  }
               });
               connection.query(RenameQuery_4, (err, result) => {
                  if (err) {
                     console.log('Error Rename Query Four');
                  }
               });

            }).catch(error_1 => {
               console.log('DROP Error');
            });
         }).catch(error => {
            console.log('INSERT Error');
         });
      }

      // MySQL Query
      var Addon_Query = '';
      TableInfo.MySQLFields.map((obj, idx) => {
         const Addon = idx + 1 === TableInfo.MySQLFields.length ? '' : ',';
         Addon_Query = Addon_Query + ' ' + obj.Key + ' ' + obj.Type + ' ' + obj.Extra + Addon;
      });
      var MySQL_Query = 'CREATE TABLE IF NOT EXISTS temp_patient_records(' + Addon_Query + ')';

      // MySQL Medication
      var Addon_Query_Med = '';
      TableInfo.MySQLMedicationFields.map((obj, idx) => {
         const Addon_Med = idx + 1 === TableInfo.MySQLMedicationFields.length ? '' : ',';
         Addon_Query_Med = Addon_Query_Med + ' ' + obj.Key + ' ' + obj.Type + ' ' + obj.Extra + Addon_Med;
      });
      var MySQL_Query_1 = 'CREATE TABLE IF NOT EXISTS temp_patient_medication(' + Addon_Query_Med + ')';

      // MySQL Treatment Modalities
      var Addon_Query_Treatment = '';
      TableInfo.MySQLTreatmentModalitiesFields.map((obj, idx) => {
         const Addon_Treatment = idx + 1 === TableInfo.MySQLTreatmentModalitiesFields.length ? '' : ',';
         Addon_Query_Treatment = Addon_Query_Treatment + ' ' + obj.Key + ' ' + obj.Type + ' ' + obj.Extra + Addon_Treatment;
      });
      var MySQL_Query_2 = 'CREATE TABLE IF NOT EXISTS temp_patient_treatment(' + Addon_Query_Treatment + ')';
      
      // MySQL Vessel Stent
      var Addon_Query_Vessel = '';
      TableInfo.MySQLVesselStentFields.map((obj, idx) => {
         const Addon_Vessel = idx + 1 === TableInfo.MySQLVesselStentFields.length ? '' : ',';
         Addon_Query_Vessel = Addon_Query_Vessel + ' ' + obj.Key + ' ' + obj.Type + ' ' + obj.Extra + Addon_Vessel;
      });
      var MySQL_Query_3 = 'CREATE TABLE IF NOT EXISTS temp_patient_vessel(' + Addon_Query_Vessel + ')';
      
      // MySQL Stents
      var Addon_Query_Stent = '';
      TableInfo.MySQLStentsFields.map((obj, idx) => {
         const Addon_Stent = idx + 1 === TableInfo.MySQLStentsFields.length ? '' : ',';
         Addon_Query_Stent = Addon_Query_Stent + ' ' + obj.Key + ' ' + obj.Type + ' ' + obj.Extra + Addon_Stent;
      });
      var MySQL_Query_4 = 'CREATE TABLE IF NOT EXISTS temp_patient_stent(' + Addon_Query_Stent + ')';


      Promise.all([
         connection.query(MySQL_Query),
         connection.query(MySQL_Query_1),
         connection.query(MySQL_Query_2),
         connection.query(MySQL_Query_3),
         connection.query(MySQL_Query_4)
      ]).then( response => {
         DataCollectInsert();
      }).catch(error => {
         console.log('CREATE TABLE Error');
      });
   }, null, true, 'Asia/Kolkata');
   job.start();
};

