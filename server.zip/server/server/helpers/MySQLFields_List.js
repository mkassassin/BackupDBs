exports.MySQLFields = [
   { Key: "id", Type: "INT", Extra: "NOT NULL AUTO_INCREMENT PRIMARY KEY"},
   { Key: "Location", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Data_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Cluster", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Name", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Gender", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Age", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Age_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Onset_Time", Type: "TIME", Extra: "NULL default NULL"},
   { Key: "Onset_Time_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Onset_To_FMC", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Onset_To_FMC_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_DateTime", Type: "DATETIME", Extra: "NULL default NULL"},
   { Key: "FMC_Arrival", Type: "TIME", Extra: "NULL default NULL"},
   { Key: "FMC_Arrival_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "ModeOf_FMC_Arrival", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_To_ECG", Type: "INT", Extra: "NULL default NULL"},
   { Key: "FMC_Arrival_To_ECG_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "ECG_To_STEMI_Confirm", Type: "INT", Extra: "NULL default NULL"},
   { Key: "ECG_To_STEMI_Confirm_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Direct_EMS", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "EMS_To", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Direct_S1", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "S1_To", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Direct_S2", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "S2_To", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Lytic", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Spoke_To_Hub_Transfer", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "ModeOf_Spoke_To_Hub_Transfer", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Risk_Factor", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Location_Of_Infarction", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Mode_Of_Payment", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolytic_Agent", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Onset_To_Thrombolysis", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Onset_To_Thrombolysis_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Needle", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Door_To_Needle_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Needle_WithIn30Min", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Needle_MoreThan30Min", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Lytic_Medication", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Onset_To_Balloon", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Onset_To_Balloon_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Balloon", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Door_To_Balloon_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Balloon_WithIn30Min", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Door_To_Balloon_MoreThan30Min", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolysis_To_Angio", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Thrombolysis_To_Angio_Period", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Successful_Lysis", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "PCI_Hospital_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Coronary_Angiography", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "PCI", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Angio_Findings", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolysis_To_PCI", Type: "INT", Extra: "NULL default NULL"},
   { Key: "Thrombolysis_To_Angio_WithIn24Hrs", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolysis_To_Angio_MoreThan24Hrs", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolysis_To_PCI_WithIn24Hrs", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Thrombolysis_To_PCI_MoreThan24Hrs", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "PCI_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Culprit_Vessel", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Culprit_Vessel_Percent", Type: "INT", Extra: "NULL default NULL"},
   { Key: "If_Additional_Vessel", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Drug_Before_PCI_Medication", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Vessel_Category", Type: "TINYTEXT", Extra: "NOT NULL"},
];
exports.MySQLMedicationFields = [
   { Key: "id", Type: "INT", Extra: "NOT NULL AUTO_INCREMENT PRIMARY KEY"},
   { Key: "Data_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Cluster", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Name", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_DateTime", Type: "DATETIME", Extra: "NULL default NULL"},
   { Key: "Category", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Medication", Type: "TINYTEXT", Extra: "NOT NULL"}
];
exports.MySQLTreatmentModalitiesFields = [
   { Key: "id", Type: "INT", Extra: "NOT NULL AUTO_INCREMENT PRIMARY KEY"},
   { Key: "Data_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Cluster", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Name", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_DateTime", Type: "DATETIME", Extra: "NULL default NULL"},
   { Key: "Value", Type: "TINYTEXT", Extra: "NOT NULL"}
];
exports.MySQLVesselStentFields = [
   { Key: "id", Type: "INT", Extra: "NOT NULL AUTO_INCREMENT PRIMARY KEY"},
   { Key: "Data_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Cluster", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Name", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_DateTime", Type: "DATETIME", Extra: "NULL default NULL"},
   { Key: "Vessel", Type: "TINYTEXT", Extra: "NOT NULL"}
];
exports.MySQLStentsFields = [
   { Key: "id", Type: "INT", Extra: "NOT NULL AUTO_INCREMENT PRIMARY KEY"},
   { Key: "Data_Type", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "Cluster", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Name", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Role", Type: "TINYTEXT", Extra: "NOT NULL"},
   { Key: "FMC_Arrival_DateTime", Type: "DATETIME", Extra: "NULL default NULL"},
   { Key: "Stent", Type: "TINYTEXT", Extra: "NOT NULL"}
];
exports.DateFields = [

];
exports.TimeFields = [
   "Onset_Time",
   "FMC_Arrival"
];
exports.DateTimeFields = [
   "FMC_Arrival_DateTime"
];
exports.IntFields = [
   "Age",
   "Onset_To_FMC",
   "FMC_Arrival_To_ECG",
   "ECG_To_STEMI_Confirm",
   "Onset_To_Thrombolysis",
   "Door_To_Needle",
   "Onset_To_Balloon",
   "Door_To_Balloon",
   "Thrombolysis_To_Angio",
   "Thrombolysis_To_PCI",
   "Culprit_Vessel_Percent"
];