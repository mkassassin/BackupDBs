var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Drug before pci
var PCIDrugBeforePciSchema = mongoose.Schema({
   PatientId: { type: Schema.Types.ObjectId, ref: 'PatientBasicDetails' },
   Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
   Pci_Drug_Before_Pci_Clopidogrel: { type: String },
   Pci_Drug_Before_Pci_Clopidogrel_Date_Time: { type: Date },
   Pci_Drug_Before_Pci_Prasugrel: { type: String },
   Pci_Drug_Before_Pci_Prasugrel_Date_Time: { type: Date },
   Pci_Drug_Before_Pci_Ticagrelor: { type: String },
   Pci_Drug_Before_Pci_Ticagrelor_Date_Time: { type: Date},
   Pci_Drug_Before_Pci_Aspirin: { type: String },
   Pci_Drug_Before_Pci_Aspirin_Dosage: { type: String },
   Pci_Drug_Before_Pci_Aspirin_Dosage_Date_Time: { type: Date},
   DrugsBeforePCIOthersArray: [{
      Pci_Drug_Before_Pci_Other_Medicine: { type: String },
      Pci_Drug_Before_Pci_Other_Medicine_Date_Time: { type: Date},
   }],
   Active_Status: { type: Boolean, required : true },
   If_Deleted: { type: Boolean, required : true }    
   },
   { timestamps: true }
);
var VarPCIDrugBeforePci = mongoose.model('PCIDrugBeforePci', PCIDrugBeforePciSchema, 'PCI-Drug-Before-Pci');

// Pci
var PciSchema = mongoose.Schema({
   PatientId: { type: Schema.Types.ObjectId, ref: 'PatientBasicDetails' },
   Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
   PCI: { type: String },
   Pci_Cath_Lab_Activation_Date_Time: { type: Date },
   Pci_Cath_Lab_Arrival_Date_Time: { type: Date },
   Pci_Vascular_Access_Date_Time: { type: Date },
   Pci_Catheter_Access: { type: String },
   Pci_Cart_Start_Date_Time: { type: Date },
   Pci_Cart_End_Date_Time: { type: Date },
   Pci_Cart: { type: String },
   PCI_Management_Conservative: { type: String },
   PCI_Management_CABG: { type: String },
   PCI_Management_CABG_Present_elective: { type: String },
   PCI_Management_CABG_Date: { type: Date },
   PCI_Management_PCI: { type: String },
   CulpritVesselArray: [{
      Pci_Culprit_Vessel: { type: String },
      Pci_Culprit_Vessel_Percent: { type: Number },
      Culprit_Vessel_Intervention: { type: Boolean },
      PCI_Intervention_Wire_Crossing: { type: String },
      PCI_Intervention_Wire_Crossing_Date_Time: { type: Date },
      PCI_Intervention_Aspiration: { type: String },
      PCI_Intervention_Balloon_Dilatation: { type: String },
      PCI_Intervention_Balloon_Dilatation_Date: { type: Date },
      PCI_Intervention_Stenting: { type: String },
      PCI_Intervention_Stenting_Date_Time: { type: Date },
      PCI_Intervention_Bms: { type: String },
      PCI_Intervention_Bms_Number_Of_Stents: { type: String },
      PCI_Intervention_DES: { type: String },
      PCI_Intervention_DES_Number_Of_Stents: { type: String },
      PCI_Intervention_MGuard: { type: String },
      PCI_Intervention_MGuard_Number_Of_Stents: { type: String },
      PCI_Intervention_TIMI_Flow: { type: String },
      PCI_Intervention_TIMI_Blush_Grade: { type: String },
   }],
   VesselArray: [{
      Pci_Cart_Vessel: { type: String },
      Pci_Cart_Vessel_Percent: { type: Number },
      PCI_Vessel_Intervention: { type: Boolean },
      PCI_Intervention_Vessel_Balloon_Dilatation: { type: String },
      PCI_Intervention_Vessel_Balloon_Dilatation_Date: { type: Date },
      PCI_Intervention_Vessel_Stenting: { type: String },
      PCI_Intervention_Vessel_Stenting_Date_Time: { type: Date },
      PCI_Intervention_Vessel_Bms: { type: String },
      PCI_Intervention_Vessel_Bms_Number_Of_Stents: { type: String },
      PCI_Intervention_Vessel_DES: { type: String },
      PCI_Intervention_Vessel_DES_Number_Of_Stents: { type: String },
      PCI_Intervention_Vessel_MGuard: { type: String },
      PCI_Intervention_Vessel_MGuard_Number_Of_Stents: { type: String },
      PCI_Intervention_Vessel_TIMI_Flow: { type: String },
      PCI_Intervention_Vessel_TIMI_Blush_Grade: { type: String },
   }],
   PCI_Intervention_IABP: { type: String },
   Active_Status: { type: Boolean, required : true },
   If_Deleted: { type: Boolean, required : true }
   },
   { timestamps: true }    
);
var VarPCIPci = mongoose.model('PCIPci', PciSchema, 'PCI-Pci');

// Medication in Cath
var PciMedicationInCathSchema = mongoose.Schema({
   PatientId: { type: Schema.Types.ObjectId, ref: 'PatientBasicDetails' },
   Hospital: { type: Schema.Types.ObjectId, ref: 'Hospital' },
   Medication_In_Cath_Nitroglycerin: { type: String },
   Medication_In_Cath_Adenosine: { type: String },
   Medication_In_Cath_Nicorandil: { type: String },
   Medication_In_Cath_Snp: { type: String },
   Medication_In_Cath_Ca_Blockers: { type: String },
   IntraCoronaryDrugsOthersArray: [{
      Intra_coronary_Other_Medicine: { type: String },
   }],
   Medication_In_Cath_Inhibitors_Abciximab: { type: String },
   Medication_In_Cath_Inhibitors_Eptifibatide: { type: String },
   Medication_In_Cath_Inhibitors_Tirofiban: { type: String },
   InhibitorsOthersArray: [{
      Inhibitors_Other_Medicine: { type: String },
   }],
   Anti_Thrombotics_Unfractionated_Heparin: { type: String },
   Anti_Thrombotics_Unfractionated_Heparin_Dosage: { type: String },
   Anti_Thrombotics_Unfractionated_Heparin_Dosage_Units: { type: String },
   Anti_Thrombotics_Unfractionated_Heparin_Dosage_Date: { type: Date },
   Anti_Thrombotics_LMW_Heparin: { type: String },
   Anti_Thrombotics_LMW_Heparin_Route: { type: String },
   Anti_Thrombotics_LMW_Heparin_Dosage: { type: String },
   Anti_Thrombotics_LMW_Heparin_Dosage_Units: { type: String },
   Anti_Thrombotics_LMW_Heparin_Dosage_Date: { type: Date },
   Anti_Thrombotics_Bivalirudin: { type: String },
   AntiThromboticsOthersArray: [{
      Anti_Thrombotics_Other_Medicine_Name: { type: String },
      Anti_Thrombotics_Other_Medicine_Route: { type: String },
      Anti_Thrombotics_Other_Medicine_Dosage: { type: String },
      Anti_Thrombotics_Other_Medicine_Dosage_Units: { type: String },
      Anti_Thrombotics_Other_Medicine_Dosage_Date_Time: { type: Date },
   }],
   Active_Status: { type: Boolean, required : true },
   If_Deleted: { type: Boolean, required : true }
   },
   { timestamps: true }
);
var VarPCIMedicationInCath = mongoose.model('PCIMedicationInCath', PciMedicationInCathSchema, 'PCI-Medication-In-Cath');

module.exports = {
    PCIDrugBeforePciSchema : VarPCIDrugBeforePci,
    PciSchema:  VarPCIPci,
    PciMedicationInCathSchema: VarPCIMedicationInCath
};