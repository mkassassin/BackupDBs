var admin = require("firebase-admin");

var AppAccount = require("./stemi-app-5f206-firebase-adminsdk.json");
var TabAccount = require("./stemi-tab-firebase-adminsdk.json");


var _first = admin.initializeApp({
               credential: admin.credential.cert(AppAccount),
               databaseURL: "https://stemi-app-5f206.firebaseio.com"
            }, 'first');

var _second = admin.initializeApp({
               credential: admin.credential.cert(TabAccount),
               databaseURL: "https://stemi-tab.firebaseio.com"
            }, 'second');

//             var payload = {
//                notification: {
//                   title: 'STEMI Confirmed',
//                   body: 'STEMI Confirmed for Patient: ttt, Age: 22, Gender: m',
//                   sound: 'notify_tone.mp3'
//                },
//             };
//             var options = {
//                priority: 'high',
//                timeToLive: 60 * 60 * 24
//             };
// _first.messaging().sendToDevice('e1J5B4ZW7lE:APA91bG5KA65MYo0hz1bvZaDo1sHnG5Amjks-U5l8znjtb3n-nKEX4sS4DvXcnDpvzAYQS-kvRSeBdkxvlPWb2mF7BwW9ToQOpv7ilNTqnqkfpa3MaF7hHg6XuN5qCq4wD3FdLqaaN-O', payload, options)
// .then((NotifyRes) => { 
//    console.log(NotifyRes);
//  }).catch(error => {
//     console.log('Error');
//     console.log(error);
//  });

exports.first = _first;
exports.second = _second;