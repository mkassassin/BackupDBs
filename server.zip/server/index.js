var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var cors = require('cors');
var path = require('path');
var mime = require('mime-types');
var fs = require('fs');
var CryptoJS = require("crypto-js");
var http = require('http');
var https = require('https');

var port = 3000;
var app = express();

// Certificate
// const credentials = {
// 	key: fs.readFileSync('./Config/ssl/portal.stemiindia.com.key', 'utf8'),
// 	cert: fs.readFileSync('./Config/ssl/portal_stemiindia_com.crt', 'utf8'),
// 	ca: [
//       fs.readFileSync('./Config/ssl/SectigoRSADomainValidationSecureServerCA.crt', 'utf8'),
//       fs.readFileSync('./Config/ssl/USERTrustRSAAAACA.crt', 'utf8')
//    ]
// };

// Local env
var server = require('http').Server(app);
// Live env
// const httpsServer = https.createServer(credentials, app);
// http.createServer(function (req, res) {
//    res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
//    res.end();
// }).listen(80);


// Local env
var io = require('socket.io')(server);
// Live env
// var io = require('socket.io')(httpsServer);
// io.origins((origin, callback) => {
//    const exactOrigin = origin.split("/")[0] + "//" + origin.split("/")[2];
//    if (exactOrigin === 'https://portal.stemiindia.com' || exactOrigin === 'http://portal.stemiindia.com' ) {
//       callback(null, true);
//    }
//    return callback('origin not allowed', false);
// });


var SocketHandling = require('./server/helpers/socket-handling');
var MySQL_Manage = require('./server/helpers/mysqlDB-handling').MySQL_Manage();
// var BPLDeviceHandling = require('./server/helpers/BPL-handling');
// BPLDeviceHandling.DirectoryWatching();

// Process On Every Error
process.env.TZ = "Asia/Kolkata";
process.setMaxListeners(0);
process.on('unhandledRejection', (reason, promise) => {
    console.error('Un Handled Rejection');
    console.log(reason);
});
process.on('uncaughtException', function (err) {
    console.error('Un Caught Exception');
    console.log(err);
});


// DB Connection
// const uri = "mongodb://localhost:27017/stemi";
const uri = "mongodb://10.10.30.156:27017/stemi-stage-new";
mongoose.connect(uri, {useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true });

// const uri = "mongodb://3.7.245.162:24874/stemi-india";
// mongoose.connect(uri, { user: 'MeanAppUser', pass: 'I3m3H4a4N8d8L3e3E4n4T8i8R3e3S4t4E8m8I', auth:{ authSource: 'admin' }, useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true });
mongoose.connection.on('error', function (err) {
    console.log('Mongodb Connection Error');
    console.log(err);
});
mongoose.connection.once('open', function () {
    console.log('DB Connectivity, Success!');
});

// Local env
app.use(cors());
app.use(require('express-status-monitor')());

// Live env
// var corsOptions = {
//    origin: 'https://portal.stemiindia.com',
//    optionsSuccessStatus: 200
// };
// app.use(cors(corsOptions));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true, parameterLimit: 50000 }));
app.use(bodyParser.json({ limit: '10mb' }));


io.on('connection', (socket) => {
   socket.emit('Existing', 'Recovery!');      
   socket.on('Recovery', (Session) => {
      if (Session !== null && Session !== '' && Session !== 'null' && Session !== undefined) {
         SocketHandling.SocketRegister(socket, Session);
      }
   });
   socket.on('Register', (token) => {
      SocketHandling.SocketRegister(socket, token);
   });
   socket.on('disconnect', () => {
      SocketHandling.SocketRegisterDeActive(socket);
   });
});


app.get('/APP_API/TeleECG-Report', express.static('Uploads/Tele-ECG-Reports'));

app.use('/API/LoginManagement/StemiUser_Login', function (req, res, next) {
   app.set('socketio', io);
   return next();
});
app.use('/API/LoginManagement/StemiUser_AutoLogin', function (req, res, next) {
   app.set('socketio', io);
   return next();
});
app.use('/API/LoginManagement/StemiUserMob_Login', function (req, res, next) {
   app.set('socketio', io);
   return next();
});

// Decrypt the Request
// app.use('/API/', function (req, res, next) {
//    var data = req.body;
//    if (data.info) {
//       var decryptedData = CryptoJS.AES.decrypt(data.info, 'Si3Tn4Ed8Mi3Ia4').toString(CryptoJS.enc.Utf8);
//       req.body = JSON.parse(decryptedData);
//    }
//    next();
// });

// Encrypt the Response
// function convertData(originalData) {
//    if (originalData[0] && originalData[0].Response) {
//       const data = JSON.stringify(originalData[0].Response);
//       var encryptedData  = CryptoJS.AES.encrypt(data, 'sI3tnN4eD8mI3iA4').toString();
//       originalData[0].Response = encryptedData;
//    }
//    return originalData;
// }

// app.use('/API/', function (req, res, next) {
//    var originalSend = res.send;
//    res.send = function(){
//       originalSend.apply(res, convertData(arguments));
//    };
//    next();
// });

// Return response Already Encrypted
require('./server/api/routes/login_management.routes')(app);

require('./server/api/routes/control_panel.routes')(app);
require('./server/api/routes/location.routes')(app);
require('./server/api/routes/patient-management/patient_details.routes')(app);
require('./server/api/routes/patient-management/thrombolysis.routes')(app);
require('./server/api/routes/patient-management/pci.routes')(app);
require('./server/api/routes/patient-management/hospital_summary.routes')(app);
require('./server/api/routes/patient-management/discharge_transfer.routes')(app);
require('./server/api/routes/patient-management/followup.routes')(app);
require('./server/api/routes/hospital_management.routes')(app);
require('./server/api/routes/global_management.routes')(app);
require('./server/api/routes/cluster_management.routes')(app);
require('./server/api/routes/user_management.routes')(app);
require('./server/api/routes/device_management.routes')(app);
require('./server/api/routes/Ask_Cardiologist_patients.routes')(app);
require('./server/api/routes/offline_patients.routes')(app);
require('./server/api/routes/BPLPatient_Management.routes')(app);
require('./server/api/routes/config_idproof.routes')(app);
require('./server/api/routes/reports.routes')(app);


// Mobile API
require('./server/mobile_api/routes/login_management.route')(app);
require('./server/mobile_api/routes/patient-management/patient_details.route')(app);
require('./server/mobile_api/routes/patient-management/patient_details_tele_ECG.route')(app);


app.use('/*.html|/*.js|/*.css|/*.png|/*.jpg|/*.svg|/*.ico|/*.ttf|/*.woff|/*.txt|/*.eot|/*.json', function (req, res, next) {
   if (req.headers['accept-encoding']) {
      const cond = req.headers['accept-encoding'].includes('gzip');
      if (cond) {
         const contentType = mime.lookup(req.originalUrl);
         req.url = req.url + '.gz';
         res.set('Content-Encoding', 'gzip');
         res.set('Content-Type', contentType);
      }
   }
   next();
});
app.use(express.static(__dirname + '/view/dist/view/'));
app.use(function(req, res) {
   res.sendFile(path.join(__dirname, '/view/dist/view', 'index.html'));
});


app.get('*', function (req, res) { 
    res.send('This is Server Side Page');
});

// Local env
server.listen(3000, function () {
    console.log('Listening on port 3000' );
});
// Live env
// httpsServer.listen(443, () => {
// 	console.log('HTTPS Server running on port 443');
// });