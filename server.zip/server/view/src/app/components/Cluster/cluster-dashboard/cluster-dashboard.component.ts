import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cluster-dashboard',
  templateUrl: './cluster-dashboard.component.html',
  styleUrls: ['./cluster-dashboard.component.css']
})
export class ClusterDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
