import { Component, OnInit, ElementRef, ViewChild, TemplateRef } from '@angular/core';
import { Subject } from 'rxjs';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { FormGroup } from '@angular/forms';
import { BplPatientsManagementService } from './../../../services/bpl-management/bpl-patients-management.service';

@Component({
  selector: 'app-modal-bpl-view',
  templateUrl: './modal-bpl-view.component.html',
  styleUrls: ['./modal-bpl-view.component.css']
})
export class ModalBplViewComponent implements OnInit {

   @ViewChild('fileInput') fileInput: ElementRef;


   onClose: Subject<any>;
   Info: any;
   ECGPreview: any;
   ECGPreviewAvailable: false;
   DynamicFGroup: FormGroup;
   ShowECGPreview = false;
   modalReference: BsModalRef;

   screenHeight: any;
   screenWidth: any;

   constructor(public modalRef: BsModalRef, public ModalService: BsModalService, public Service: BplPatientsManagementService,
      ) { }

   ngOnInit() {
      this.onClose = new Subject();
      this.Service.Load_BPL_ECG({BplId: this.Info._id}).subscribe( response => {
         this.Info.ECG_File = response.Response;
      });
      this.getScreenSize();
   }

   getScreenSize(event?: any) {
      this.screenHeight = window.innerHeight - 80;
      this.screenWidth = window.innerWidth - 40;
   }

   EcgView(template: TemplateRef<any>) {
      this.modalReference = this.ModalService.show(template, { class: 'second'} );
   }

}
