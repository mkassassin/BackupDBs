
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { tap } from 'rxjs/operators';

@Injectable({
   providedIn: 'root'
})
export class MyInterceptor implements HttpInterceptor {

   AuthorizeKey = '';
   encryptedBody = '';

   constructor() {
   }

   intercept( request: HttpRequest<any>, next: HttpHandler ): Observable<HttpEvent<any>> {
      if (localStorage.getItem('Session') && localStorage.getItem('SessionKey')) {
         let UserData = CryptoJS.AES.decrypt(localStorage.getItem('Session'), localStorage.getItem('SessionKey').slice(3, 10)).toString(CryptoJS.enc.Utf8);
         UserData = JSON.parse(UserData);
         UserData.Token = localStorage.getItem('SessionKey');
         this.AuthorizeKey = CryptoJS.SHA512(JSON.stringify(UserData)).toString(CryptoJS.enc.Hex);
         localStorage.setItem('SessionVerify', btoa(Date()));
      }
      if (request.method === 'POST') {
         const data = JSON.stringify(request.body);
         this.encryptedBody = CryptoJS.AES.encrypt(data, 'Si3Tn4Ed8Mi3Ia4').toString();
      }
      const updatedRequest = request.clone({
         body: {info: this.encryptedBody},
         headers: request.headers.set('Authorization', this.AuthorizeKey)
      });

      return next.handle(updatedRequest).pipe( tap((event: HttpEvent<any>) => {
         if (event instanceof HttpResponse) {
            if (event.body.Response) {
               const data = CryptoJS.AES.decrypt(event.body.Response, 'sI3tnN4eD8mI3iA4').toString(CryptoJS.enc.Utf8);
               event.body.Response = JSON.parse(data);
            }
            return event;
         }
       }, (err: any) => {
         if (err instanceof HttpErrorResponse) {
            return err;
         }
       }));
   }

}
