import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/Location/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/Location/';
const LiveURL = 'https://portal.stemiindia.com/API/Location/';

const httpOptions = {
  headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class LocationService {

   constructor(private http: HttpClient) { }

   StemiLocation_AsyncValidate(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'StemiLocation_AsyncValidate', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   StemiLocation_Create(data: any): Observable<any> {
     return this.http.post<any>(LiveURL + 'StemiLocation_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   StemiLocations_List(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'StemiLocations_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   StemiLocations_SimpleList(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'StemiLocations_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   StemiLocation_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'StemiLocation_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

}
