import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/Global_Management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/Global_Management/';
const LiveURL = 'https://portal.stemiindia.com/API/Global_Management/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CommonService {


   constructor(private http: HttpClient) { }

   GetCountries(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Country_List' , data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   GetStates(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'State_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   GetCities(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'City_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

}
