import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/ControlPanel/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/ControlPanel/';
const LiveURL = 'https://portal.stemiindia.com/API/ControlPanel/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class UnderProcessService {

   constructor(private http: HttpClient) { }


   All_Fields(): Observable<any> {
      return this.http.get<any>(LiveURL + 'All_Fields', httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   TypeBased_Validations(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'TypeBased_Validations', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   All_Validations(): Observable<any> {
      return this.http.get<any>(LiveURL + 'All_Validations', httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }


   All_Fields_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'All_Fields_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }


}
