import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/Config_Management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/Config_Management/';
const LiveURL = 'https://portal.stemiindia.com/API/Config_Management/';

const httpOptions = {
  headers: new HttpHeaders({  'Content-Type':  'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class IdproofManagementService {

   constructor(private http: HttpClient) { }

   IdProofConfig_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'IdProofConfig_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Cluster_IdProofUpdate(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'Cluster_IdProofUpdate', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   IdProof_ConfigList(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'IdProof_ConfigList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   ClusterConfig_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'ClusterConfig_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   ClusterConfig_DetailedView(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'ClusterConfig_DetailedView', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   IdProofConfig_Delete(data: any): Observable<any> {
      return this.http.post<any>(LiveURL  + 'IdProofConfig_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
}
