import { Injectable } from '@angular/core';

import * as io from 'socket.io-client';
import {Observable, of} from 'rxjs';

const DevURL = 'http://localhost:3000/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/';
const LiveURL = 'https://portal.stemiindia.com/';


@Injectable({
  providedIn: 'root'
})
export class SocketManagementService {

   socket: SocketIOClient.Socket;
   private User: any = null;

   constructor() { }

   Initiate() {
      this.socket = io.connect(LiveURL, {secure: true});

      // this.socket.on('Alert', (msg: any) => {
      //    console.log(msg);
      // });

      // this.socket.on('Success', (msg: any) => {
      //    console.log(msg);
      // });

      this.socket.on('Existing', (msg: any) => {
         this.socket.emit('Recovery', localStorage.getItem('SessionKey'));
      });

   }

   // GetUser() {
   //    if (this.User === undefined || this.User === null || this.User === '') {
   //       this.socket.emit('GetUser', localStorage.getItem('SessionKey'));
   //       return Observable.create( observer => {
   //          this.socket.on('User', (response) => {
   //             this.User = JSON.parse(response);
   //             observer.next(this.User);
   //             observer.complete();
   //          });
   //       });
   //    } else {
   //       return of(this.User);
   //    }
   // }

   Handling(Str: string) {
      this.socket.emit(Str, localStorage.getItem('SessionKey'));
      return Observable.create( observer => {
         this.socket.on(Str, (response) => {
            observer.next(response);
            observer.complete();
         });
      });
   }

}
