import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/DeviceManagement/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/DeviceManagement/';
const LiveURL = 'https://portal.stemiindia.com/API/DeviceManagement/';

const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
 };

@Injectable({
  providedIn: 'root'
})
export class DeviceManagementService {

   constructor(private http: HttpClient) { }

   Device_AsyncValidate(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Device_AsyncValidate', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Device_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Device_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Devices_List(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Devices_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Device_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Device_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Device_Delete(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Device_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

}
