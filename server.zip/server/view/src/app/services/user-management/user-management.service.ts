import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/UserManagement/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/UserManagement/';
const LiveURL = 'https://portal.stemiindia.com/API/UserManagement/';


const httpOptions = {
  headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

constructor(private http: HttpClient) { }

StemiUser_AsyncValidate(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUser_AsyncValidate', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiUser_Create(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUser_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiUsers_List(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUsers_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiUsers_Delete(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUsers_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiUser_Update(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUser_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiUserActive_Status(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiUserActive_Status', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}



}
