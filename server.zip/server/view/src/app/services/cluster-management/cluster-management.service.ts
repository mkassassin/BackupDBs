import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/Cluster_Management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/Cluster_Management/';
const LiveURL = 'https://portal.stemiindia.com/API/Cluster_Management/';


const httpOptions = {
  headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ClusterManagementService {

constructor(private http: HttpClient) { }

StemiCluster_Create(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiCluster_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiCluster_View(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiCluster_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiCluster_Update(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiCluster_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

StemiCluster_AsyncValidate(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'StemiCluster_AsyncValidate', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

Clusters_SimpleList(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'Clusters_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

ClusterBased_Hospitals(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'ClusterBased_Hospitals', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

ClusterBased_ControlPanelFields(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'ClusterBased_ControlPanelFields', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

ClusterControlPanel_Update(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'ClusterControlPanel_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

ClustersSimpleList_LocationBased(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'ClustersSimpleList_LocationBased', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

ClusterDetails_RequiredForMapping(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'ClusterDetails_RequiredForMapping', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

Add_HospitalTo_Cluster(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'Add_HospitalTo_Cluster', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

Remove_HospitalFrom_Cluster(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'Remove_HospitalFrom_Cluster', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}


}
