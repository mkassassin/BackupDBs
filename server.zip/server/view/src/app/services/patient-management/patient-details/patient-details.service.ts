import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { LoginManagementService } from '../../login-management/login-management.service';

const DevURL = 'http://localhost:3000/API/patient_management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/patient_management/';
const LiveURL = 'https://portal.stemiindia.com/API/patient_management/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};
@Injectable({
  providedIn: 'root'
})

export class PatientDetailsService {
   UserInfo: any;
   ClusterType: any;

   constructor(private http: HttpClient, private LoginService: LoginManagementService) {   }

   PatientBasicDetails_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientBasicDetails_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   AllPatients_List(data: any): Observable<any> {
      const UserInfo = JSON.parse(this.LoginService.LoginUser_Info());
      if (UserInfo.User_Type === 'SA') {
         return this.http.post<any>(LiveURL + 'AllPatientDetails_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'CO') {
            return this.http.post<any>(LiveURL + 'CoordinatorBasedPatients_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'PU') {
         if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'multiple' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'MultipleClusterBased_Patients', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'single' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'SingleClusterBased_Patients', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if (UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'advanced') {
            return this.http.post<any>(LiveURL + 'AdvancedClusterBased_Patients', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else {
            return this.http.post<any>(LiveURL + 'HospitalBased_Patients', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         }
      } else {
         return this.http.post<any>(LiveURL + 'HospitalBased_Patients', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      }
   }

   AllPatients_Count(data: any): Observable<any> {
      const UserInfo = JSON.parse(this.LoginService.LoginUser_Info());
      if (UserInfo.User_Type === 'SA') {
         return this.http.post<any>(LiveURL + 'AllPatientDetails_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'CO') {
            return this.http.post<any>(LiveURL + 'CoordinatorBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'PU') {
         if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'multiple' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'MultipleClusterBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'single' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'SingleClusterBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if (UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'advanced') {
            return this.http.post<any>(LiveURL + 'AdvancedClusterBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else {
            return this.http.post<any>(LiveURL + 'HospitalBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         }
      } else {
         return this.http.post<any>(LiveURL + 'HospitalBasedPatients_Count', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      }
   }



   AllPatients_SimpleList(data: any): Observable<any> {
      const UserInfo = JSON.parse(this.LoginService.LoginUser_Info());
      if (UserInfo.User_Type === 'SA') {
         return this.http.post<any>(LiveURL + 'AllPatientDetails_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'CO') {
            return this.http.post<any>(LiveURL + 'CoordinatorBasedPatients_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'PU') {
         if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'multiple' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'MultipleClusterBased_PatientsSimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'single' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'SingleClusterBased_PatientsSimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if (UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'advanced') {
            return this.http.post<any>(LiveURL + 'AdvancedClusterBased_PatientsSimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else {
            return this.http.post<any>(LiveURL + 'HospitalBased_PatientsSimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         }
      } else {
         return this.http.post<any>(LiveURL + 'HospitalBased_PatientsSimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      }
   }
   ECG_Files_Report(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ECG_Files_Report', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientData_Export(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientData_Export', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientBasicDetails_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientBasicDetails_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientBasicDetails_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientBasicDetails_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientDidNotArrive_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientDidNotArrive_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Patient_Delete(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Patient_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   ECG_Files(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ECG_Files', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Update_Ninety_Min_ECG(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Update_Ninety_Min_ECG', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Update_FollowUp_ECG(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Update_FollowUp_ECG', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   AdmissionType(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'AdmissionType', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   PatientFibrinolyticChecklist_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientFibrinolyticChecklist_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientFibrinolyticChecklist_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientFibrinolyticChecklist_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientFibrinolyticChecklist_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientFibrinolyticChecklist_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   PatientMedicationDuringTransportation_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientMedicationDuringTransportation_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientMedicationDuringTransportation_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientMedicationDuringTransportation_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientMedicationDuringTransportation_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientMedicationDuringTransportation_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   PatientCardiacHistory_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCardiacHistory_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientCardiacHistory_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCardiacHistory_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientCardiacHistory_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCardiacHistory_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   PatientCoMorbidCondition_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCoMorbidCondition_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientCoMorbidCondition_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCoMorbidCondition_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientCoMorbidCondition_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCoMorbidCondition_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   PatientContactDetails_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientContactDetails_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientContactDetails_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientContactDetails_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientContactDetails_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientContactDetails_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   AllNotification_List(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Notifications_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Notifications_Viewed(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Notifications_Viewed', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Notification_Counts(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Notification_Counts', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Viewed_Notifications_Delete(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Viewed_Notifications_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }





   PatientNonCluster_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientNonCluster_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientBasicHospital_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientBasicHospital_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientBasicTransport_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientBasicTransport_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientClinical_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientClinical_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientCheckList_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientCheckList_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   PatientChecklist_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'PatientChecklist_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
}
