import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/patient_management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/patient_management/';
const LiveURL = 'https://portal.stemiindia.com/API/patient_management/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ThrombolysisService {

   constructor(private http: HttpClient) { }


   ThrombolysisMedication_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ThrombolysisMedication_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   ThrombolysisMedication_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ThrombolysisMedication_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   ThrombolysisMedication_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ThrombolysisMedication_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }


   Thrombolysis_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Thrombolysis_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Thrombolysis_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Thrombolysis_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   Thrombolysis_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Thrombolysis_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

}
