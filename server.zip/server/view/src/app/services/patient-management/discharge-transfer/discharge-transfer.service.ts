import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/patient_management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/patient_management/';
const LiveURL = 'https://portal.stemiindia.com/API/patient_management/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class DischargeTransferService {

constructor(private http: HttpClient) { }

   DischargeTransferDeath_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDeath_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferDeath_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDeath_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferDeath_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDeath_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }


   DischargeTransferMedication_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferMedication_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferMedication_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferMedication_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferMedication_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferMedication_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   TransferHistoryMedication_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'TransferHistoryMedication_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   TransferHistoryMedication_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'TransferHistoryMedication_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }



   DischargeTransferDischarge_Create(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDischarge_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferDischarge_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDischarge_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeTransferDischarge_View(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeTransferDischarge_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeHistory_Update(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeHistory_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }



   DischargeHospitals_ClusterBased(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeHospitals_ClusterBased', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeAmbulance_LocationBased(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeAmbulance_LocationBased', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }
   DischargeOther_Clusters(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'DischargeOther_Clusters', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

}
