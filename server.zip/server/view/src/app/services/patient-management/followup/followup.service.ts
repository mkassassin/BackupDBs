import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

const DevURL = 'http://localhost:3000/API/patient_management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/patient_management/';
const LiveURL = 'https://portal.stemiindia.com/API/patient_management/';


const httpOptions = {
   headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class FollowupService {

constructor(private http: HttpClient) { }

FollowUpDetails_Create(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpDetails_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpDetails_View(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpDetails_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpDetails_Update(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpDetails_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpHistory_Update(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'FollowUpHistory_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}


FollowUpMedication_Create(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpMedication_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpMedication_View(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpMedication_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpMedication_Update(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpMedication_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpMedicationHistory_Update(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'FollowUpMedicationHistory_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpMedicationHistory_Create(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'FollowUpMedicationHistory_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

FollowUpEvents_Create(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpEvents_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpEvents_View(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpEvents_View', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpEvents_Update(data: any): Observable<any> {
  return this.http.post<any>(LiveURL + 'FollowUpEvents_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpEventsHistory_Update(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'FollowUpEventsHistory_Update', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}
FollowUpEventsHistory_Create(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'FollowUpEventsHistory_Create', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
}

}
