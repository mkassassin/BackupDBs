import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { LoginManagementService } from '../login-management/login-management.service';


const DevURL = 'http://localhost:3000/API/Hospital_Management/';
const StageURL = 'http://stemi-meanstack.pptssolutions.com/API/Hospital_Management/';
const LiveURL = 'https://portal.stemiindia.com/API/Hospital_Management/';

const httpOptions = {
  headers: new HttpHeaders({  'Content-Type':  'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class HospitalManagementService {

   constructor(private http: HttpClient, private LoginService: LoginManagementService) { }

   Create_Hospital(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Create_Hospital', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospitals_List(data: any): Observable<any> {
      const UserInfo = JSON.parse(this.LoginService.LoginUser_Info());
      if (UserInfo.User_Type === 'CO') {
         const ClusterIds = UserInfo.ClustersArray.map(obj => obj._id);
         data.Clusters = ClusterIds;
         return this.http.post<any>(LiveURL + 'Hospitals_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else {
         return this.http.post<any>(LiveURL + 'Hospitals_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      }
   }

   Hospitals_All_List(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospitals_All_List', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Update_Hospital(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Update_Hospital', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_view(data: any): Observable<any> {
   return this.http.post<any>(LiveURL + 'Hospital_view', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_Approve(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_Approve', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_Reject(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_Reject', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_Block(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_Block', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_UnBlock(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_UnBlock', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_Delete(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_Delete', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   HubHospitals_SimpleList(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'HubHospitals_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Location_HubHospitals(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Location_HubHospitals', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   ClusterEdit_HubHospitals(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'ClusterEdit_HubHospitals', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Location_HubHospitals_AlsoMapped(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Location_HubHospitals_AlsoMapped', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_SimpleList(data: any): Observable<any> {
      return this.http.post<any>(LiveURL + 'Hospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
   }

   Hospital_SimpleList_UserBased(data: any): Observable<any> {
      const UserInfo = JSON.parse(this.LoginService.LoginUser_Info());
      if (UserInfo.User_Type === 'SA') {
         return this.http.post<any>(LiveURL + 'Hospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'CO') {
            return this.http.post<any>(LiveURL + 'CoordinatorBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      } else if (UserInfo.User_Type === 'PU') {
         if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'multiple' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'MultipleClusterBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if ( UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'single' &&  UserInfo.Hospital.Cluster_ConnectionType === 'ClusterHub') {
            return this.http.post<any>(LiveURL + 'SingleClusterBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else if (UserInfo.Hospital.If_Cluster_Mapped === true  && UserInfo.Cluster.Cluster_Type === 'advanced') {
            return this.http.post<any>(LiveURL + 'AdvancedClusterBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         } else {
            return this.http.post<any>(LiveURL + 'HospitalBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
         }
      } else {
         return this.http.post<any>(LiveURL + 'HospitalBasedHospital_SimpleList', data, httpOptions).pipe( map(res => res), catchError(err => of(err)) );
      }
   }


}
